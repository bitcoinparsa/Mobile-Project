package com.example.my_project;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.my_project.database.TaskDatabaseHelper;
import com.example.my_project.model.Task;

public class AddEditTaskActivity extends AppCompatActivity {

    private EditText edtTitle, edtDescription, edtDate;
    private Spinner spinnerCategory;
    private Button btnSave;

    private TaskDatabaseHelper db;
    private int taskId = -1; // اگر -1 باشد یعنی افزودن

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_task);

        edtTitle = findViewById(R.id.edtTitle);
        edtDescription = findViewById(R.id.edtDescription);
        edtDate = findViewById(R.id.edtDate);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        btnSave = findViewById(R.id.btnSave);

        db = new TaskDatabaseHelper(this);

        // Spinner نوع کار
        String[] categories = {"درسی", "شخصی", "سایر"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                categories
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        // بررسی حالت ویرایش
        if (getIntent().hasExtra("task_id")) {
            taskId = getIntent().getIntExtra("task_id", -1);
            loadTaskData();
        }

        btnSave.setOnClickListener(v -> saveTask());
    }

    private void loadTaskData() {
        for (Task task : db.getAllTasks()) {
            if (task.getId() == taskId) {
                edtTitle.setText(task.getTitle());
                edtDescription.setText(task.getDescription());
                edtDate.setText(task.getDate());

                if (task.getCategory() != null) {
                    int position = ((ArrayAdapter) spinnerCategory.getAdapter())
                            .getPosition(task.getCategory());
                    spinnerCategory.setSelection(position);
                }
                break;
            }
        }
    }

    private void saveTask() {
        String title = edtTitle.getText().toString().trim();
        String description = edtDescription.getText().toString().trim();
        String date = edtDate.getText().toString().trim();
        String category = spinnerCategory.getSelectedItem().toString();

        if (TextUtils.isEmpty(title)) {
            edtTitle.setError("عنوان الزامی است");
            return;
        }

        if (taskId == -1) {
            // افزودن
            Task task = new Task(title, description, category, date, false);
            db.addTask(task);
            Toast.makeText(this, "کار اضافه شد", Toast.LENGTH_SHORT).show();
        } else {
            // ویرایش
            Task task = new Task(taskId, title, description, category, date, false);
            db.updateTask(task);
            Toast.makeText(this, "کار ویرایش شد", Toast.LENGTH_SHORT).show();
        }

        finish();
    }
}
