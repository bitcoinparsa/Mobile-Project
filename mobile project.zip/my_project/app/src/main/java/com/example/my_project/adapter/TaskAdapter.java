package com.example.my_project.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.my_project.R;
import com.example.my_project.model.Task;

import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    private Context context;
    private List<Task> taskList;
    private OnTaskListener listener;

    // اینترفیس ارتباط با Activity
    public interface OnTaskListener {
        void onItemClick(Task task);
        void onItemLongClick(Task task);
        void onStatusChange(Task task, boolean isDone);
    }

    public TaskAdapter(Context context, List<Task> taskList, OnTaskListener listener) {
        this.context = context;
        this.taskList = taskList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_task, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);

        holder.txtTitle.setText(task.getTitle());
        holder.txtCategory.setText(task.getCategory());
        holder.txtDate.setText(task.getDate());
        holder.checkDone.setChecked(task.isDone());

        // کلیک برای ویرایش
        holder.itemView.setOnClickListener(v ->
                listener.onItemClick(task)
        );

        // نگه داشتن برای حذف
        holder.itemView.setOnLongClickListener(v -> {
            listener.onItemLongClick(task);
            return true;
        });

        // تغییر وضعیت انجام شده
        holder.checkDone.setOnCheckedChangeListener((buttonView, isChecked) ->
                listener.onStatusChange(task, isChecked)
        );
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    static class TaskViewHolder extends RecyclerView.ViewHolder {

        TextView txtTitle, txtCategory, txtDate;
        CheckBox checkDone;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);

            txtTitle = itemView.findViewById(R.id.txtTitle);
            txtCategory = itemView.findViewById(R.id.txtCategory);
            txtDate = itemView.findViewById(R.id.txtDate);
            checkDone = itemView.findViewById(R.id.checkDone);
        }
    }
}
