package com.example.my_project;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.my_project.adapter.TaskAdapter;
import com.example.my_project.database.TaskDatabaseHelper;
import com.example.my_project.model.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity
        implements TaskAdapter.OnTaskListener {

    private RecyclerView recyclerView;
    private FloatingActionButton fabAdd;
    private TaskAdapter adapter;
    private TaskDatabaseHelper db;
    private List<Task> taskList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        fabAdd = findViewById(R.id.fabAdd);

        db = new TaskDatabaseHelper(this);
        taskList = db.getAllTasks();

        adapter = new TaskAdapter(this, taskList, this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // دکمه افزودن کار
        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddEditTaskActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshList();
    }

    private void refreshList() {
        taskList.clear();
        taskList.addAll(db.getAllTasks());
        adapter.notifyDataSetChanged();
    }

    // کلیک → ویرایش
    @Override
    public void onItemClick(Task task) {
        Intent intent = new Intent(this, AddEditTaskActivity.class);
        intent.putExtra("task_id", task.getId());
        startActivity(intent);
    }

    // نگه داشتن → حذف
    @Override
    public void onItemLongClick(Task task) {
        new AlertDialog.Builder(this)
                .setTitle("حذف کار")
                .setMessage("آیا از حذف این کار مطمئن هستید؟")
                .setPositiveButton("بله", (dialog, which) -> {
                    db.deleteTask(task.getId());
                    refreshList();
                    Toast.makeText(this, "کار حذف شد", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("خیر", null)
                .show();
    }

    // تغییر وضعیت انجام شده
    @Override
    public void onStatusChange(Task task, boolean isDone) {
        task.setDone(isDone);
        db.updateTask(task);
    }
}
