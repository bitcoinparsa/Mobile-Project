package com.example.my_project.model;

public class Task {

    private int id;
    private String title;
    private String description;
    private String category; // درسی، شخصی، سایر
    private String date;     // تاریخ به صورت String
    private boolean isDone;

    // سازنده بدون id (برای افزودن)
    public Task(String title, String description, String category, String date, boolean isDone) {
        this.title = title;
        this.description = description;
        this.category = category;
        this.date = date;
        this.isDone = isDone;
    }

    // سازنده کامل (برای خواندن از دیتابیس)
    public Task(int id, String title, String description, String category, String date, boolean isDone) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.category = category;
        this.date = date;
        this.isDone = isDone;
    }

    // Getter و Setter ها
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public boolean isDone() {
        return isDone;
    }

    public void setDone(boolean done) {
        isDone = done;
    }
}
